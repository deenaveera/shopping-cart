<head>
  <title>Wrench Shoppy</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/custom.css'); ?>">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Wrench</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url('products'); ?>">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('products'); ?>">Products</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('checkout'); ?>">Checkout</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('products'); ?>">Add Items</a>
      </li>
    </ul>
	<div class="cart-item ml-auto">
		<!-- Cart basket -->
		<div class="cart-view">
			<a href="<?php echo base_url('cart'); ?>" title="View Cart"><i class="fa fa-shopping-cart" aria-hidden="true"></i> <?php echo ($this->cart->total_items() > 0)?$this->cart->total_items().' Items':'Wrench Cart'; ?></a>
		</div>
	</div>
  </div>
</nav>