	
<!-- List all products -->
<div class="container">
	<h2 class="text-center pt-4">Wrench - Shoppy Products</h2>
	<div class="row py-5">
		<!-- List all products -->
		<?php if(!empty($products)){ foreach($products as $row){ ?>
        <div class="col-lg-4">
		   <div class="card custom-card">
            <img class="card-img-top" src="<?php echo base_url('uploads/product_images/'.$row['image']); ?>" alt="" width="250" height="250" >
            <div class="card-body">
                <h5 class="card-title"><?php echo $row["name"]; ?></h5>
                <h6 class="card-subtitle mb-2 text-muted">Price: <?php echo '₹'.$row["price"].' IND'; ?></h6>
                <p class="card-text"><?php echo $row["description"]; ?></p>
                <a href="<?php echo base_url('products/addToCart/'.$row['id']); ?>" class="btn btn-primary">Add to Cart</a>
            </div>
			</div>
        </div>
    <?php } }else{ ?>
        <p>Product(s) not found...</p>
    <?php } ?>
	</div>
</div>